package com.example.mymarket;

import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.database.Cursor;
import android.database.sqlite.*;
import android.graphics.Typeface;
import android.view.*;
import android.widget.*;
import java.text.NumberFormat;
import java.util.Locale;

public class MainActivity extends Activity {
    DB db; LinearLayout root, list; TextView summary;
    NumberFormat money = NumberFormat.getCurrencyInstance(new Locale("id","ID"));
    int green = 0xFF16794B, dark = 0xFF125F3B;

    public void onCreate(Bundle b) {
        super.onCreate(b);
        db = new DB(this);
        getWindow().setStatusBarColor(dark); getWindow().setNavigationBarColor(dark);
        build();
    }
    String rp(long n) { return "Rp" + String.format(Locale.US, "%,d", n).replace(",", "."); }
    TextView text(String s, int size, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size);
        if (bold) t.setTypeface(null, Typeface.BOLD);
        t.setTextColor(0xFF202124); t.setPadding(0,6,0,6); return t;
    }
    Button button(String s) {
        Button b = new Button(this); b.setText(s); b.setAllCaps(false); return b;
    }
    void build() {
        ScrollView scroll = new ScrollView(this);
        root = new LinearLayout(this); root.setOrientation(1); root.setPadding(24,20,24,24);
        root.setBackgroundColor(0xFFF7F8F7);
        scroll.addView(root); setContentView(scroll);
        TextView title = text("My Market", 27, true); title.setTextColor(dark); root.addView(title);
        root.addView(text("Offline grocery inventory", 14, false));
        summary = text("", 15, true); summary.setPadding(14,18,14,18);
        summary.setBackgroundColor(0xFFE4F1E9); root.addView(summary);
        LinearLayout actions = new LinearLayout(this); actions.setOrientation(0);
        Button add = button("+ Add product"); add.setOnClickListener(v -> addProduct());
        Button refresh = button("Refresh"); refresh.setOnClickListener(v -> render());
        actions.addView(add,new LinearLayout.LayoutParams(0,-2,1)); actions.addView(refresh);
        root.addView(actions);
        root.addView(text("PRODUCTS", 14, true));
        list = new LinearLayout(this); list.setOrientation(1); root.addView(list);
        render();
    }
    void render() {
        if (list == null) return;
        list.removeAllViews();
        Cursor c = db.getReadableDatabase().rawQuery("SELECT id,name,price,cost,stock,min_stock FROM products ORDER BY name", null);
        int count=0, units=0, low=0;
        while(c.moveToNext()) {
            count++; int id=c.getInt(0); String name=c.getString(1);
            long price=c.getLong(2), cost=c.getLong(3); int stock=c.getInt(4), min=c.getInt(5);
            units+=stock; if(stock<=min) low++;
            LinearLayout card = new LinearLayout(this); card.setOrientation(1);
            card.setPadding(16,12,16,12); card.setBackgroundColor(0xFFFFFFFF);
            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1,-2); cp.setMargins(0,6,0,8); card.setLayoutParams(cp);
            card.addView(text(name,18,true));
            card.addView(text("Jual: "+rp(price)+"   |   Modal: "+rp(cost),14,false));
            TextView st=text("Stok: "+stock+" unit"+(stock<=min?"  •  STOK MENIPIS":""),15,true);
            if(stock<=min) st.setTextColor(0xFFB3261E); card.addView(st);
            LinearLayout row=new LinearLayout(this);
            Button sell=button("Jual"); sell.setOnClickListener(v -> sellProduct(id,name,price,cost,stock));
            Button restock=button("Tambah stok"); restock.setOnClickListener(v -> restock(id,name));
            Button edit=button("Edit"); edit.setOnClickListener(v -> editProduct(id,name,price,cost,stock,min));
            row.addView(sell,new LinearLayout.LayoutParams(0,-2,1));
            row.addView(restock,new LinearLayout.LayoutParams(0,-2,1));
            row.addView(edit,new LinearLayout.LayoutParams(0,-2,1));
            card.addView(row); list.addView(card);
        }
        c.close();
        summary.setText("Produk: "+count+"     Total stok: "+units+"     Stok menipis: "+low);
        if(count==0) list.addView(text("Belum ada produk. Tekan + Add product untuk mulai.",15,false));
    }
    EditText field(String hint, String value, boolean numeric) {
        EditText e=new EditText(this); e.setSingleLine(true); e.setHint(hint); e.setText(value);
        if(numeric) e.setInputType(2); return e;
    }
    void addProduct() {
        LinearLayout box=new LinearLayout(this); box.setPadding(12,0,12,0); box.setOrientation(1);
        EditText name=field("Nama produk","",false), price=field("Harga jual (Rp)","",true),
            cost=field("Harga modal (Rp)","",true), stock=field("Stok awal","0",true), min=field("Peringatan stok minimum","5",true);
        box.addView(name); box.addView(price); box.addView(cost); box.addView(stock); box.addView(min);
        new AlertDialog.Builder(this).setTitle("Tambah produk").setView(box)
          .setNegativeButton("Batal",null).setPositiveButton("Simpan",(d,w)->{
            try {
                if(name.getText().toString().trim().isEmpty()) throw new Exception();
                ContentValues x=new ContentValues(); x.put("name",name.getText().toString().trim());
                x.put("price",Long.parseLong(price.getText().toString())); x.put("cost",Long.parseLong(cost.getText().toString()));
                x.put("stock",Integer.parseInt(stock.getText().toString())); x.put("min_stock",Integer.parseInt(min.getText().toString()));
                db.getWritableDatabase().insertOrThrow("products",null,x); render();
            } catch(Exception e){ toast("Periksa data produk. Semua angka harus diisi dengan benar."); }
          }).show();
    }
    void sellProduct(int id,String name,long price,long cost,int stock) {
        EditText qty=field("Jumlah terjual","1",true);
        new AlertDialog.Builder(this).setTitle("Catat penjualan: "+name).setView(qty)
          .setNegativeButton("Batal",null).setPositiveButton("Simpan",(d,w)->{
            try {
                int n=Integer.parseInt(qty.getText().toString()); if(n<=0||n>stock) throw new Exception();
                SQLiteDatabase s=db.getWritableDatabase(); s.execSQL("UPDATE products SET stock=stock-? WHERE id=?",new Object[]{n,id});
                ContentValues x=new ContentValues(); x.put("product_name",name); x.put("quantity",n);
                x.put("total",price*n); x.put("profit",(price-cost)*n); x.put("sold_at",System.currentTimeMillis());
                s.insert("sales",null,x); render(); toast("Penjualan tersimpan.");
            } catch(Exception e){toast("Jumlah tidak valid atau stok tidak cukup.");}
          }).show();
    }
    void restock(int id,String name) {
        EditText qty=field("Jumlah stok masuk","1",true);
        new AlertDialog.Builder(this).setTitle("Tambah stok: "+name).setView(qty)
          .setNegativeButton("Batal",null).setPositiveButton("Tambah",(d,w)->{
            try { int n=Integer.parseInt(qty.getText().toString()); if(n<=0) throw new Exception();
              db.getWritableDatabase().execSQL("UPDATE products SET stock=stock+? WHERE id=?",new Object[]{n,id}); render();
            } catch(Exception e){toast("Jumlah harus lebih dari nol.");}
          }).show();
    }
    void editProduct(int id,String old,long p,long c,int st,int mn) {
        LinearLayout box=new LinearLayout(this); box.setOrientation(1); box.setPadding(12,0,12,0);
        EditText name=field("Nama",old,false), price=field("Harga jual",String.valueOf(p),true),
          cost=field("Harga modal",String.valueOf(c),true), stock=field("Stok",String.valueOf(st),true),
          min=field("Stok minimum",String.valueOf(mn),true);
        box.addView(name);box.addView(price);box.addView(cost);box.addView(stock);box.addView(min);
        new AlertDialog.Builder(this).setTitle("Edit produk").setView(box)
          .setNegativeButton("Batal",null).setNeutralButton("Hapus",(d,w)->new AlertDialog.Builder(this)
            .setMessage("Hapus "+old+"?").setNegativeButton("Batal",null).setPositiveButton("Hapus",(a,b)->{
              db.getWritableDatabase().delete("products","id=?",new String[]{String.valueOf(id)});render();
            }).show())
          .setPositiveButton("Simpan",(d,w)->{
            try { ContentValues x=new ContentValues(); x.put("name",name.getText().toString().trim());
              x.put("price",Long.parseLong(price.getText().toString())); x.put("cost",Long.parseLong(cost.getText().toString()));
              x.put("stock",Integer.parseInt(stock.getText().toString())); x.put("min_stock",Integer.parseInt(min.getText().toString()));
              db.getWritableDatabase().update("products",x,"id=?",new String[]{String.valueOf(id)});render();
            } catch(Exception e){toast("Data tidak valid.");}
          }).show();
    }
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
    static class DB extends SQLiteOpenHelper {
        DB(Context c){super(c,"mymarket.db",null,1);}
        public void onCreate(SQLiteDatabase d){
            d.execSQL("CREATE TABLE products(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,price INTEGER NOT NULL,cost INTEGER NOT NULL,stock INTEGER NOT NULL,min_stock INTEGER NOT NULL)");
            d.execSQL("CREATE TABLE sales(id INTEGER PRIMARY KEY AUTOINCREMENT,product_name TEXT,quantity INTEGER,total INTEGER,profit INTEGER,sold_at INTEGER)");
        }
        public void onUpgrade(SQLiteDatabase d,int a,int b){}
    }
}
